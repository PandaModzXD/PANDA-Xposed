# Xposed Injector
Xposed Injector to mod games externally. Made by Saygus, and project fixed by Spring Musk. 

Spring Musk requested me to upload his project because he don't have PC

I don't support this project, follow his Telegram channel for latest updates: https://t.me/Layout_musk

And also check out other project https://github.com/springmusk026/XPOSED-INJECTOR-FOR-FREEFIRE
